//#ifndef _SYSTICK_H
//#define _SYSTICK_H
//#include "stm32f10x.h"

//void Delay_us( uint32_t us);
//void Delay_ms( uint32_t ms);

//#endif
#ifndef _SysTick_H
#define _SysTick_H

#include "sys.h"

void SysTick_Init(u8 SYSCLK);




#endif
