#ifndef __ESP8266_H
#define __ESP8266_H

void ESP8266_Init();

void ESP8266_SendData(int data);
#endif
